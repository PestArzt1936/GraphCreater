﻿//{{NO_DEPENDENCIES}}
// Включаемый файл, созданный в Microsoft Visual C++.
// Используется GraphCreater.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_GraphCreaterTYPE            130
#define IDD_CMATRIXDLG                  312
#define IDC_CUSTOMBOX                   1001
#define ID_Vertical                     32773
#define ID_EDGE                         32774
#define ID_CHANGENAME                   32783
#define ID_CREATEMATRIX                 32784
#define ID_BUTTONCURSOR                 32785

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           312
#endif
#endif
