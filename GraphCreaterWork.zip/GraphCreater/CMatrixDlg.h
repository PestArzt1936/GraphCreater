﻿#pragma once
#include "afxdialogex.h"
#include "Vertical.h"
#include "Edge.h"
#include "GraphCreaterDoc.h"
#include "CMatrixView.h"


// Диалоговое окно CMatrixDlg

class CMatrixDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CMatrixDlg)
	CGraphCreaterDoc* pDoc = nullptr;
	CMatrixView MatrixRuler;
public:
	CMatrixDlg(CWnd* pParent = nullptr);   // стандартный конструктор
	virtual ~CMatrixDlg();
	afx_msg void ClickedOK();
	void SetDocument(CGraphCreaterDoc* doc);
// Данные диалогового окна
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CMatrixDlg };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // поддержка DDX/DDV

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};
