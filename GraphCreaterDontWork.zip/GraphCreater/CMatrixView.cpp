﻿// CMatrixView.cpp: файл реализации
//

#include "pch.h"
#include "GraphCreater.h"
#include "CMatrixView.h"


// CMatrixView
#define CUSTOMBOX_CLASSNAME L"CustomBox"
IMPLEMENT_DYNAMIC(CMatrixView, CWnd)

CMatrixView::CMatrixView()
{
	RegisterClass();
}
bool CMatrixView::RegisterClass()
{
	WNDCLASS wndcls;
	HINSTANCE hInst = AfxGetInstanceHandle();
	if (!(::GetClassInfo(hInst, CUSTOMBOX_CLASSNAME, &wndcls))) {
		wndcls.style = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
		wndcls.lpfnWndProc = ::DefWindowProc;
		wndcls.cbClsExtra = wndcls.cbWndExtra = 0;
		wndcls.hInstance = hInst;
		wndcls.hIcon = NULL;
		wndcls.hCursor = AfxGetApp()->LoadStandardCursor(IDC_ARROW);
		wndcls.hbrBackground = (HBRUSH)(COLOR_3DFACE + 1);
		wndcls.lpszMenuName = NULL;
		wndcls.lpszClassName = CUSTOMBOX_CLASSNAME;
		if (!AfxRegisterClass(&wndcls)) {
			AfxThrowResourceException();
			return false;
		}
	}
	return true;
}
CMatrixView::~CMatrixView()
{
}


BEGIN_MESSAGE_MAP(CMatrixView, CWnd)
	ON_WM_PAINT()
END_MESSAGE_MAP()

void CMatrixView::OnPaint() {
	CPaintDC dc(this);
	CPen ourPen;
	HGDIOBJ oldpen;
	ourPen.CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
	oldpen = dc.SelectObject(ourPen);
	dc.Rectangle(10, 10, 200, 200);
	dc.SelectObject(oldpen);
	ourPen.DeleteObject();
}

// Обработчики сообщений CMatrixView


