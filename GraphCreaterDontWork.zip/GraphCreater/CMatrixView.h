﻿#pragma once


// CMatrixView

class CMatrixView : public CWnd
{
	DECLARE_DYNAMIC(CMatrixView)
	bool RegisterClass();
public:
	CMatrixView();
	virtual ~CMatrixView();
	afx_msg void OnPaint();
protected:
	DECLARE_MESSAGE_MAP()
};


