﻿// CMatrixDlg.cpp: файл реализации
//

#include "pch.h"
#include "GraphCreater.h"
#include "afxdialogex.h"
#include "CMatrixDlg.h"


// Диалоговое окно CMatrixDlg
#define CUSTOMBOX_CLASSNAME L"CustomBox"
IMPLEMENT_DYNAMIC(CMatrixDlg, CDialogEx)

CMatrixDlg::CMatrixDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CMATRIXDLG, pParent)
{

}

CMatrixDlg::~CMatrixDlg()
{
}

void CMatrixDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CUSTOMBOX, MatrixRuler);
}


BEGIN_MESSAGE_MAP(CMatrixDlg, CDialogEx)
	ON_BN_CLICKED(IDOK,&CMatrixDlg::ClickedOK)
END_MESSAGE_MAP()

void CMatrixDlg::ClickedOK() {
	this->EndDialog(IDOK);
}
// Обработчики сообщений CMatrixDlg
void CMatrixDlg::SetDocument(CGraphCreaterDoc* doc) {
	this->pDoc = doc;
}

BOOL CMatrixDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	CRect rect(10, 10, 200, 200);
	if (!MatrixRuler.Create(CUSTOMBOX_CLASSNAME, _T(""), WS_CHILD | WS_VISIBLE, rect, this, IDC_CUSTOMBOX)) {
		AfxMessageBox(_T("Failed to create custom control"));
		return false;
	}
	// TODO:  Добавить дополнительную инициализацию

	return TRUE;  // return TRUE unless you set the focus to a control
	// Исключение: страница свойств OCX должна возвращать значение FALSE
}
